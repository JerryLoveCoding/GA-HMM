import numpy as np
import Deal_Data.Data_Processing as DP
import Lamda as LA
import os

"""
参考李航统计学习方法4.2贝叶斯估计
"""


def Prior_Matrix(Hidden_List):
    """
    先验概率矩阵
    :param Hidden_List:
    :return:
    """
    Prior_List = LA.Lamda_PI(Hidden_List)
    return Prior_List


def Bayes_Matrix(Hidden_List, observe_data):
    """
    条件概率矩阵，部分过程和HMM的B矩阵差不多
    :param Hidden_List:
    :param observe_data:
    :return:
    """
    Bayes_List = []
    for i in range(4):
        observe_list = observe_data[i]
        Bayes_List.append(LA.Lamda_B(observe_list, Hidden_List).tolist())
    Bayes_List = np.asarray(Bayes_List)

    return Bayes_List


def Bayes_Program(Prior_List, Bayes_Matrix, observe_data):
    Hidden_List = []
    for i in range(30):
        Probability_List = []  # 对于每一个时间点，节点处于5个隐状态的概率列表，每个时间点取概率最大的
        element_list = observe_data[:, i]

        for j in range(5):
            tempo = Prior_List[j]
            for index, element in enumerate(element_list):
                tempo *= Bayes_Matrix[index][element][j]
            Probability_List.append(tempo)


        Probability_Max = max(Probability_List)
        Probability_index = Probability_List.index(Probability_Max)  # 该时间点贝叶斯下的估计状态
        Hidden_List.append(Probability_index)
    return Hidden_List

def Bayes_Algo():
    for i in range(780):
        if os.path.exists("../Data/linear_data/" + str(i) + ".csv"):
            observe_datapath = "../Data/linear_data/" + str(i) + ".csv"
            observe_data = DP.importdata_nohead(observe_datapath)
            hidden_path = "../Data/linear_origin_hidden/" + str(i) + ".csv"
            Hidden_origin_List = DP.importdata_nohead(hidden_path)
            Hidden_origin_List = Hidden_origin_List[-1]

            Prior_List = Prior_Matrix(Hidden_origin_List)
            Bayes_matrix = Bayes_Matrix(Hidden_origin_List, observe_data)
            Hidden_List = Bayes_Program(Prior_List, Bayes_matrix, observe_data)
            savepath = "../Data/Bayes_predict_list/" + str(i) + ".csv"
            save_hidden = [Hidden_List]
            np.savetxt(savepath, save_hidden, fmt="%s", delimiter=",")





if __name__ == "__main__":
    # datapath = "../Data/linear_data/21.csv"
    # observe_data = DP.importdata_nohead(datapath)
    # hidden_path = "../Data/linear_origin_hidden/21.csv"
    # Hidden_origin_List = DP.importdata_nohead(hidden_path)
    # Hidden_origin_List = Hidden_origin_List[-1]
    # print(Hidden_origin_List)
    # Prior_List = Prior_Matrix(Hidden_origin_List)
    # Bayes_Matrix = Bayes_Matrix(Hidden_origin_List, observe_data)
    # print(Bayes_Matrix)
    # Hidden_List = Bayes_Program(Prior_List, Bayes_Matrix, observe_data)
    # print(Hidden_List)
    Bayes_Algo()



