import numpy as np
import importlib
import pandas as pd
import Lamda_Parameter as LP
import Lamda as LA


def BW_ABPI(A, B, PI, observe_Select, Alfa, Beta, Gamma, Epsilon):
    """
    Baumwelch中迭代的A，B，PI和alfa，beta，gamma，epsilon各个参数
    :param A:
    :param B:
    :param PI:
    :param observe_Select:
    :param Alfa:
    :param Beta:
    :param Gamma:
    :param Epsilon:
    :return:
    """
    new_A = A*0
    new_B = B*0
    new_PI = PI*0
    new_Alfa = Alfa*0
    new_Beta = Beta*0
    new_Gamma = Gamma*0
    new_Epsilon = Epsilon*0

    Q = [0, 1, 2, 3, 4]  # 隐状态集合
    V = [0, 1, 2]  # 观测状态集合
    T = 30  # 时间序列长度
    for i in range(5):  # new_A
        for j in range(5):
            Molecular_A = sum(Epsilon[t][i][j] for t in range(T-1))  # A的分子项
            Denominator_A = sum(Gamma[t][i] for t in range(T-1))  # A的分母项
            new_A[i][j] = Molecular_A/Denominator_A

    for k in range(3):  # new_B
        for j in range(5):
            Molecular_B = sum(Gamma[t][j] for t in range(T) if observe_Select[t] == V[k])
            Denominator_B = sum(Gamma[t][j] for t in range(T))
            new_B[k][j] = Molecular_B/Denominator_B

    for i in range(5):  # new_PI
        new_PI[i] = Gamma[1][i]

    new_Alfa = LP.Forward_Algorithm(observe_Select, new_A, new_B, new_PI)
    new_Beta = LP.Backward_Algorithm(observe_Select, new_A, new_B, new_PI)
    new_Gamma, new_Epsilon = LP.Gamma_Epsilon(observe_Select, new_A, new_B, new_Alfa, new_Beta)

    return new_A, new_B, new_PI, new_Alfa, new_Beta, new_Gamma, new_Epsilon


def judgeA(A):
    """
    判断迭代中的A，是否sum超过1.1，防止过拟合
    :param A:
    :return: 如果有一个sum超过1，判断为ture过拟合，跳出这次循环不计入迭代的A
    """
    result = False
    for i in A:
        if sum(i) >= 1.1:
            result = True
            break
    return result



def BaumWelch(Hidden_Time_List, observe_datapath, K, Num_Iterate):
    """
    BaumWelch算法
    :param observe_datapath: Kmeans分类后的数据路径
    :param K: 选取哪一个特征进行HMM
    :param Num_Iterate: BaumWelch迭代次数
    :return: 迭代后稳定的lamda
    """
    observe_Select, Hidden_Time_List0, PI0, LamdaA0, LamdaB0 = LA.Lamda(Hidden_Time_List, observe_datapath, K)

    It_A = []  # 迭代的A，每次迭代后的新值放在这里
    It_B = []  # 迭代的B
    It_PI = []  # 迭代的PI

    # Lamda的初值如下
    It_A.append(LamdaA0)
    It_B.append(LamdaB0)
    It_PI.append(PI0)

    Alfa = []  # 迭代的Alfa
    Beta = []  # 迭代的Beta
    Alfa0 = LP.Forward_Algorithm(observe_Select, It_A[0], It_B[0], It_PI[0])
    Beta0 = LP.Backward_Algorithm(observe_Select, It_A[0], It_B[0], It_PI[0])
    Alfa.append(Alfa0)
    Beta.append(Beta0)

    Gamma = []  # 迭代的Gamma
    Epsilon = []  # 迭代的Epsilon
    Gamma0, Epsilon0 = LP.Gamma_Epsilon(observe_Select, It_A[0], It_B[0], Alfa0, Beta0)
    Gamma.append(Gamma0)
    Epsilon.append(Epsilon0)

    # 循环迭代各个参数
    j = 0
    for i in range(Num_Iterate):
        new_A, new_B, new_PI, new_Alfa, new_Beta, new_Gamma, new_Epsilon = BW_ABPI(It_A[j], It_B[j], It_PI[j],
                                                                                   observe_Select,
                                                                                   Alfa[j], Beta[j], Gamma[j],
                                                                                   Epsilon[j])

        if judgeA(new_A):  # 如果有一个sum超过1，判断为ture过拟合，跳出这次循环不计入迭代的A
            continue
        It_A.append(new_A)
        It_B.append(new_B)
        It_PI.append(new_PI)
        Alfa.append(new_Alfa)
        Beta.append(new_Beta)
        Gamma.append(new_Gamma)
        Epsilon.append(new_Epsilon)
        j += 1

    return It_A[-1], It_B[-1], It_PI[-1]
