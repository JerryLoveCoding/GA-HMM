import numpy as np
import os
import random
import Deal_Data.Data_Processing as DP
import Baum_Welch as BW
import Vertbi_Decoding as VD
import Information_Gain as IG
import GA_HMM.G_A as GA  # 用到了信息增益和列表函数
import MarkovChainPredict as MCP


def best_IG_Hidden(observe_data, iter_I):
    """
    最大增益的Hidden list
    :param iter_I:
    :return:
    """
    IG_list = GA.make_fit_list(observe_data, iter_I)
    max_index = IG_list.index(max(IG_list))
    best_hidden = iter_I[max_index]

    return best_hidden


def operatemodel():
    for i in range(780):
        if os.path.exists("../Data/linear_data/"+str(i)+".csv"):
            observe_datapath = "../Data/linear_data/"+str(i)+".csv"
            observe_data = DP.importdata_nohead(observe_datapath)
            hidden_path = "../Data/linear_origin_hidden/" + str(i) + ".csv"
            Hidden_list = DP.importdata_nohead(hidden_path)
            Hidden_list = Hidden_list[0]  # 二维转一维

            iter_I = []  # 迭代中的隐状态序列，最后只有一个
            for j in range(4):  # iter_I赋初值
                A, B, PI = BW.BaumWelch(Hidden_list, observe_datapath, j, 10)
                tempo = VD.Vtb(A, B, PI, observe_data[j])
                tempo = tempo.tolist()
                iter_I.append(tempo)
            best_hidden = best_IG_Hidden(observe_data, iter_I)
            save_hidden = [best_hidden]  # 保存文件的格式是二维的
            savepath = "../Data/Classic_predict_list/"+str(i)+".csv"

            np.savetxt(savepath, save_hidden, fmt="%s", delimiter=",")


def markovProgram_Classic():
    predict_result_list = np.zeros(780, np.int)
    for i in range(780):
        if os.path.exists("../Data/Classic_predict_list/"+str(i)+".csv"):
            datapath = "../Data/Classic_predict_list/"+str(i)+".csv"
            Hidden_List = DP.importdata_nohead(datapath)
            Hidden_List = Hidden_List[0]  # 因为importdata读出的数据是二维的（虽然只有一行数据）将其转为一维的
            pre_result = MCP.markovchain(Hidden_List)
            predict_result_list[i] = pre_result+1
            predict_result_list = [predict_result_list]
    savepath = "predict_result/Classic_result.csv"
    np.savetxt(savepath, predict_result_list, fmt="%s", delimiter=',')

if __name__ == "__main__":
    operatemodel()